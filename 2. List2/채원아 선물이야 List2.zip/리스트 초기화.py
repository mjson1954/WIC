arr=[0,0,0,0,0]
arr=[0]*5
arr=[i for i in range(2,9) if i%2==0] #[2,4,6,8]

brr=[[1,2,3],[1,2,3],[1,2,3]]
brr=[[1,2,3]]*3
brr=[[1,2,3] for i in range(3)]
brr=[[i,j] for i in range(3) for j in range(2)]
